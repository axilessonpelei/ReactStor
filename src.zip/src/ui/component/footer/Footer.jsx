import './Footer.css';

const Footer = () => {
    return (
        <footer className="footer">
            <p>
                 rtk market<br />
                 теперь купер <br />
                покупай эти вещи и участвуй в розыгрыше курса с 0 до 2100
            </p>
        </footer>
    );
};

export default Footer;
