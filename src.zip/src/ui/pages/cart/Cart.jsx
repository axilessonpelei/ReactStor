import React, { useContext } from "react";
import "./Cart.css";
import { Context } from "../../../core/context/context.jsx";

export const Cart = () => {
  return (
    <div>
      <h1>Cart</h1>
    </div>
  );
};
